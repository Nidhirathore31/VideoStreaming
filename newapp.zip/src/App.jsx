import React from 'react'
import './App.css'
import{BrowserRouter as Router,Routes,Route} from 'react-router-dom'
import Nav from './components/Home/Nav'
import Footer from './components/footer/Footer';
import Home from './components/Home';
import HistoryPage from './components/HistoryPage';
import Categories from './components/Categories';


function App() {
 

  return (
    <>
   <Nav/>
   {/* <Home/> */}
   {/* <HistoryPage/> */}
  
    {/* <Routes>
      <Route path='/' element={<Home/>}></Route>

    </Routes> */}
     
     <Routes> 
      <Route path='/c' element={<Categories/>}></Route>
     </Routes>
     <Footer/>
   
    
   
    </>
  )
}

export default App;
