import React from 'react'
import Home from '../Home'
import Channels from '../Channels'
import SingleChannel from '../SingleChannel'
import VideoPage from '../VideoPage'
import VideoUP from '../VideoUP'
import HistoryPage from '../HistoryPage'
import History from '../History'
import Categories from '../Categories'
import Login from '../page/Login'
import Register from '../page/Register'
import Subscription from '../Subscription'
import { Link, Route, Router, Routes } from 'react-router-dom'


const Nav = () => {
  return (
  <>
    <div id="page-top">
                <nav className="navbar navbar-expand navbar-light bg-white static-top osahan-nav sticky-top">
                    &nbsp;&nbsp;
                    <button className="btn btn-link btn-sm text-secondary order-1 order-sm-0" id="sidebarToggle">
                        <i className="fas fa-bars" />
                      </button> &nbsp;&nbsp;
                    <a className="navbar-brand mr-1" href="index.html"><img className="img-fluid" alt src="img/logo.png" /></a>
                    {/* Navbar Search */}
                    <form className="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-5 my-2 my-md-0 osahan-navbar-search">
                        <div className="input-group">
                            <input type="text" className="form-control" placeholder="Search for..." />
                            <div className="input-group-append">
                                <button className="btn btn-light" type="button">
                                    <i className="fas fa-search" />
                                </button>
                            </div>
                        </div>
                    </form>
                    {/* Navbar */}
                    <ul className="navbar-nav ml-auto ml-md-0 osahan-right-navbar">
                        <li className="nav-item mx-1">
                            <a className="nav-link" href="upload.html">
                                <i className="fas fa-plus-circle fa-fw" />
                                Upload Video
                            </a>
                        </li>
                        <li className="nav-item dropdown no-arrow mx-1">
                            <a className="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i className="fas fa-bell fa-fw" />
                                <span className="badge badge-danger">9+</span>
                            </a>
                            <div className="dropdown-menu dropdown-menu-right" aria-labelledby="alertsDropdown">
                                <a className="dropdown-item" href="#"><i className="fas fa-fw fa-edit " /> &nbsp; Action</a>
                                <a className="dropdown-item" href="#"><i className="fas fa-fw fa-headphones-alt " /> &nbsp; Another action</a>
                                <div className="dropdown-divider" />
                                <a className="dropdown-item" href="#"><i className="fas fa-fw fa-star " /> &nbsp; Something else here</a>
                            </div>
                        </li>
                        <li className="nav-item dropdown no-arrow mx-1">
                            <a className="nav-link dropdown-toggle" href="#" id="messagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i className="fas fa-envelope fa-fw" />
                                <span className="badge badge-success">7</span>
                            </a>
                            <div className="dropdown-menu dropdown-menu-right" aria-labelledby="messagesDropdown">
                                <a className="dropdown-item" href="#"><i className="fas fa-fw fa-edit " /> &nbsp; Action</a>
                                <a className="dropdown-item" href="#"><i className="fas fa-fw fa-headphones-alt " /> &nbsp; Another action</a>
                                <div className="dropdown-divider" />
                                <a className="dropdown-item" href="#"><i className="fas fa-fw fa-star " /> &nbsp; Something else here</a>
                            </div>
                        </li>
                        <li className="nav-item dropdown no-arrow osahan-right-navbar-user">
                            <a className="nav-link dropdown-toggle user-dropdown-link" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <img alt="Avatar" src="img/user.png" />
                                Osahan
                            </a>
                            <div className="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
                                <a className="dropdown-item" href="account.html"><i className="fas fa-fw fa-user-circle" /> &nbsp; My Account</a>
                                <a className="dropdown-item" href="subscriptions.html"><i className="fas fa-fw fa-video" /> &nbsp; Subscriptions</a>
                                <a className="dropdown-item" href="settings.html"><i className="fas fa-fw fa-cog" /> &nbsp; Settings</a>
                                <div className="dropdown-divider" />
                                <a className="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal"><i className="fas fa-fw fa-sign-out-alt" /> &nbsp; Logout</a>
                            </div>
                        </li>
                    </ul>
                </nav>
                <div id="wrapper">

                    {/* Sidebar */} 
                    <ul className="sidebar navbar-nav">
                        <li className="nav-item active">
                            <Link className="nav-link" to="/">
                                <i className="fas fa-fw fa-home" />
                              Home
                            </Link>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" href="channels.html">
                                <i className="fas fa-fw fa-users" />
                                <span>Channels</span>
                            </a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" href="single-channel.html">
                                <i className="fas fa-fw fa-user-alt" />
                                <span>Single Channel</span>
                            </a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" href="video-page.html">
                                <i className="fas fa-fw fa-video" />
                                <span>Video Page</span>
                            </a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" href="upload-video.html">
                                <i className="fas fa-fw fa-cloud-upload-alt" />
                                <span>Upload Video</span>
                            </a>
                        </li>
                        <li className="nav-item dropdown">
                            <a className="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i className="fas fa-fw fa-folder" />
                                <span>Pages</span>
                            </a>
                            <div className="dropdown-menu">
                                <h6 className="dropdown-header">Login Screens:</h6>
                                <a className="dropdown-item" href="login.html">Login</a>
                                <a className="dropdown-item" href="register.html">Register</a>
                                <a className="dropdown-item" href="forgot-password.html">Forgot Password</a>
                                <div className="dropdown-divider" />
                                <h6 className="dropdown-header">Other Pages:</h6>
                                <a className="dropdown-item" href="404.html">404 Page</a>
                                <a className="dropdown-item" href="blank.html">Blank Page</a>
                            </div>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" href="history-page.html">
                                <i className="fas fa-fw fa-history" />
                                <span>History Page</span>
                            </a>
                        </li>
                        <li className="nav-item dropdown">
                            <a className="nav-link dropdown-toggle" href="categories.html" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i className="fas fa-fw fa-list-alt" />
                                <span>Categories</span>
                            </a>
                            <div className="dropdown-menu">
                                <a className="dropdown-item" href="categories.html">Movie</a>
                                <a className="dropdown-item" href="categories.html">Music</a>
                                <a className="dropdown-item" href="categories.html">Television</a>
                            </div>
                        </li>
                        <li className="nav-item channel-sidebar-list">
                            <h6>SUBSCRIPTIONS</h6>
                            <ul>
                                <li>
                                    <a href="subscriptions.html">
                                        <img className="img-fluid" alt src="img/s1.png" /> Your Life
                                    </a>
                                </li>
                                <li>
                                    <a href="subscriptions.html">
                                        <img className="img-fluid" alt src="img/s2.png" /> Unboxing  <span className="badge badge-warning">2</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="subscriptions.html">
                                        <img className="img-fluid" alt src="img/s3.png" /> Product / Service
                                    </a>
                                </li>
                                <li>
                                    <a href="subscriptions.html">
                                        <img className="img-fluid" alt src="img/s4.png" />  Gaming
                                    </a>
                                </li>
                            </ul>
                        </li>
                    </ul> </div>
                    
                         <Home/>
                    
                   
     <VideoUP/>
    <Channels/>
    <SingleChannel/>
    <VideoPage/> 
    <HistoryPage/>
    {/* <History/> */}
    <Categories/>
    <Login/>
    <Register/>
    <Subscription/>
   
                    </div>
                  
  </>
  )
}

export default Nav
